# anhphat-backend

## Install dependencies

```sh
npm i
```

## Run project

```sh
npm start
```
